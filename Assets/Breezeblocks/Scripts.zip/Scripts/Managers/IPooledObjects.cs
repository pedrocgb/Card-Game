﻿public interface IPooledObjects
{
    void OnSpawn();
}
