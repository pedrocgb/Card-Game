
[System.Serializable]
public class EffectBlock
{
    public UEnums.CardEffects EffectType;
    public int Amount;
    public int Duration;
}
